# Mirai Repository Request — Response & Safe Alternatives

I cannot provide, edit, or redistribute original Mirai malware source code or any modified/weaponized version of it. That would be assisting wrongdoing and is illegal and unsafe.

Instead, this ZIP contains **safe, legal, and educational** materials:
- A clear explanation of why I refused the original request.
- A high-level, non-actionable guide about Mirai (history and defensive lessons).
- A practical IoT defense checklist you can use to secure devices and networks.
- A *benign example* (simple distributed task runner demonstration) that teaches networking and client/server concepts without any malware functionality.

Files in this archive:
- README.md (this file)
- GUIDE.md (high-level, non-actionable guide and references)
- DEFENSE_CHECKLIST.md (practical IoT hardening checklist)
- benign_example/server.py (benign task server — safe to run locally)
- benign_example/client.py (benign client that polls the server for tasks)
- LICENSE.txt

If you'd like changes to the materials, or an expanded benign example (e.g., a web UI, Dockerfile, tests), tell me what you want and I will modify the ZIP accordingly.
