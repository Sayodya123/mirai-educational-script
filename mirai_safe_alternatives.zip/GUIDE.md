# Guide: Mirai — High-level Summary & Defensive Lessons (Non-actionable)

**Important:** This guide is intentionally high-level and non-actionable. It explains historical context and defensive lessons you can use to protect systems. It does NOT include exploit code, configuration to attack, or instructions for creating botnets.

## 1. What Mirai was (summary)
- Mirai is a family of IoT botnet malware first widely reported in 2016.
- It primarily propagated by trying common default usernames/passwords and logging into exposed services (e.g., Telnet).
- Compromised devices were enlisted into botnets to perform large-scale DDoS attacks and network scanning for other vulnerable devices.
- The original Mirai source leaked publicly, which led to many mirrors and forks.

## 2. Why Mirai was effective
- Many IoT devices shipped with default credentials and lacked easy update mechanisms.
- Devices often remained online 24/7 and had public-facing services.
- Vendors and users did not consistently apply firmware updates or network segmentation.

## 3. Defensive lessons (conceptual)
- Assume devices may be targeted — apply defense-in-depth.
- Remove or change default credentials before exposing devices to networks.
- Use network segmentation and least-privilege network rules.
- Monitor device behavior and outbound traffic for anomalies (e.g., spikes in connections, scanning patterns).
- Maintain inventory of devices and their firmware support status; retire unsupported devices.

## 4. Safe research practices (high-level)
- Use air-gapped or isolated virtual labs for malware analysis.
- Only analyze malware in controlled environments and under legal/ethical approval.
- Share findings responsibly with vendors and CERTs — do not redistribute exploit code.

## 5. References & further reading
- Security vendor write-ups and government advisories (KrebsOnSecurity, CISA) provide incident timelines and defensive guidance.
- Academic courses on malware analysis, secure firmware, and network defense for structured learning.
