# IoT Defense Checklist (Practical, Actionable - Defensive Only)

Use this checklist to harden IoT devices and small networks.

## Pre-deployment
- Change all factory-default passwords; use unique strong passwords.
- Disable unused management interfaces (Telnet, UPnP).
- Enable SSH with key-based authentication where possible.
- Place IoT devices on a dedicated VLAN or network segment.
- Restrict outbound traffic from IoT VLAN using egress filtering (allow only necessary destinations/ports).

## Ongoing maintenance
- Keep firmware up to date; subscribe to vendor security advisories.
- Replace devices that no longer receive security updates.
- Maintain an inventory: device model, firmware version, serial number, owner/location.
- Enforce strong password policies and rotate credentials if possible.

## Monitoring & detection
- Log device behavior and monitor for:
  - Unusual outbound connections (to many distinct IPs).
  - High connection rates or spikes in bandwidth.
  - Connections to known malicious command-and-control (C2) infrastructure.
- Use network-based anomaly detection (flow monitoring, NetFlow) and integrate alerts into SIEM.
- Rate-limit or block scanning-like outbound behavior at network edge when feasible.

## Incident response (high-level)
- Isolate suspected devices from the network (quarantine VLAN).
- Preserve forensic artifacts (logs, packet captures).
- Reimage or factory-reset devices, then reconfigure securely.
- Notify affected parties and follow disclosure/reporting procedures.

## User education
- Train users to change default credentials and report unusual device behavior.
- Provide simple onboarding checklists for new devices.
