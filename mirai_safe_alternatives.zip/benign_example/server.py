#!/usr/bin/env python3
"""Benign example server: simple task server for educational purposes.

This server exposes a tiny HTTP API that returns JSON tasks.
Clients poll `/task` and print what the server returns.
This is intentionally benign: tasks are simple text messages and no code execution is performed.
Run locally (python3 server.py) and point clients to it.
"""

from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import time

TASKS = [
    {"id": 1, "action": "print", "message": "Hello from the task server!"},
    {"id": 2, "action": "print", "message": "This is a benign example."},
    {"id": 3, "action": "print", "message": "Modify this example safely for learning."}
]

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/task"):
            # simple round-robin task
            task = TASKS[int(time.time()) % len(TASKS)]
            payload = {"task": task}
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

def run(host="127.0.0.1", port=8000):
    server = HTTPServer((host, port), Handler)
    print(f"Benign task server listening on http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Shutting down server")
        server.server_close()

if __name__ == "__main__":
    run()
