#!/usr/bin/env python3
"""Benign example client: polls the task server and prints tasks.

This client demonstrates safe networking and does not perform any harmful actions.
Run: python3 client.py
"""

import requests
import time

SERVER = "http://127.0.0.1:8000"

def poll_once():
    try:
        r = requests.get(SERVER + "/task", timeout=5)
        r.raise_for_status()
        data = r.json()
        task = data.get("task", {})
        print(f"Received task id={task.get('id')} action={task.get('action')} message={task.get('message')}")
    except Exception as e:
        print("Error polling server:", e)

def main():
    print("Starting benign client. Press Ctrl+C to stop.")
    while True:
        poll_once()
        time.sleep(5)

if __name__ == "__main__":
    main()
